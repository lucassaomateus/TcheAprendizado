# TcheAprendizado

Projeto acadêmico desenvolvido para a disciplina de Modelagem de Software (PPGES) — UNIPAMPA 2026.

**Autor:** Lucas Alves São Mateus

## Sobre o produto

TcheAprendizado é uma plataforma EdTech focada na família, que permite ao responsável fotografar o material didático do aluno e receber questões personalizadas geradas por IA, com diagnóstico imediato do aprendizado e reforço automático para os erros identificados.

**Escopo:** Educação Infantil ao 9º ano do Ensino Fundamental.

## Estrutura do repositório

```
TcheAprendizado/
├── diagramas/
│   └── bpmn/               # Diagramas BPMN em PlantUML (.puml)
├── latex/                  # Arquivos LaTeX de cada capítulo
└── overleaf/               # Projeto completo para importar no Overleaf
```

## Capítulos produzidos

- ✅ Capítulo 1 — Resumo Executivo
- ✅ Capítulo 2 — Introdução
- ✅ Capítulo 3 — Engenharia de Requisitos
- 🔄 Capítulo 4 — Modelo de Negócio (em andamento)
- ⏳ Capítulo 5 — Modelo de Sistema
- ⏳ Capítulo 6 — Lições Aprendidas
- ⏳ Capítulo 7 — Conclusão

## Como visualizar os diagramas BPMN

1. Acesse [plantuml.com/plantuml/uml](https://www.plantuml.com/plantuml/uml/)
2. Cole o conteúdo do arquivo `.puml`
3. A imagem é gerada automaticamente
